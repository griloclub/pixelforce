package model;

public interface ModelFormat {
	void addLineListener(String fileLine);
}
