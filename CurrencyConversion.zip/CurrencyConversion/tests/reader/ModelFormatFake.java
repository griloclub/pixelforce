package reader;

import model.ModelFormat;

public class ModelFormatFake implements ModelFormat {

	@Override
	public void addLineListener(String fileLine) {
	}
}
